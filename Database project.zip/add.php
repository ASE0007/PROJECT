<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
    <style>
        /* General Body Styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #4facfe, #00f2fe);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        /* Container Styling */
        .container {
            background: rgba(0, 0, 0, 0.7);
            padding: 20px 30px;
            border-radius: 10px;
            width: 350px;
            text-align: center;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5);
        }

        /* Heading Styling */
        h1 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #ffdd57;
        }

        /* Form Input and Button Styling */
        form input, form button {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }

        form input {
            background: #f0f0f0;
            color: #333;
        }

        form button {
            background: #ffdd57;
            color: #333;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        form button:hover {
            background: #ffcc00;
        }

        /* Success and Error Messages */
        .success {
            color: #4caf50;
            margin-top: 10px;
        }

        .error {
            color: #f44336;
            margin-top: 10px;
        }

        /* Go to Home Button */
        .home-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background: #5bc0de;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .home-btn:hover {
            background: #3498db;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add Book</h1>
        <form method="post">
            <input type="text" name="title" placeholder="Book Title" required>
            <input type="text" name="author" placeholder="Author" required>
            <input type="text" name="genre" placeholder="Genre" required>
            <input type="number" name="year" placeholder="Year" min="1000" max="9999" required>
            <input type="number" name="quantity" placeholder="Quantity" min="1" required>
            <button type="submit" name="add">Add Book</button>
        </form>

        <?php
        if (isset($_POST['add'])) {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $genre = $_POST['genre'];
            $year = $_POST['year'];
            $quantity = $_POST['quantity'];

            // Check for an exact match in the database
            $check_sql = "SELECT * FROM books WHERE title = '$title' AND author = '$author' AND genre = '$genre' AND year = $year";
            $result = $conn->query($check_sql);

            if ($result->num_rows > 0) {
                // If match found, update the quantity
                $update_sql = "UPDATE books SET quantity = quantity + $quantity WHERE title = '$title' AND author = '$author' AND genre = '$genre' AND year = $year";
                if ($conn->query($update_sql) === TRUE) {
                    echo "<p class='success'>Book quantity updated successfully!</p>";
                } else {
                    echo "<p class='error'>Error updating quantity: " . $conn->error . "</p>";
                }
            } else {
                // If no match found, insert a new row
                $insert_sql = "INSERT INTO books (title, author, genre, year, quantity) VALUES ('$title', '$author', '$genre', $year, $quantity)";
                if ($conn->query($insert_sql) === TRUE) {
                    echo "<p class='success'>Book added successfully!</p>";
                } else {
                    echo "<p class='error'>Error adding book: " . $conn->error . "</p>";
                }
            }
        }
        ?>

       
    </div>
</body>
</html>
