<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Book</title>
</head>
<body style="font-family: Arial, sans-serif; background: linear-gradient(to right, #4facfe, #00f2fe); color: #333; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0;">

    <div style="background: rgba(255, 255, 255, 0.9); padding: 20px 30px; border-radius: 10px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5); width: 400px; text-align: center;">
        <h2 style="color: #d9534f; margin-bottom: 20px;">Delete Book</h2>
        <form method="post" style="display: flex; flex-direction: column; gap: 15px;">
            <input type="number" name="id" placeholder="Enter Book ID to Delete" required style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; width: 100%;">
            <button type="submit" name="delete" style="background-color: #d9534f; color: white; padding: 10px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; transition: background-color 0.3s;">
                Delete Book
            </button>
        </form>
        <?php
        if (isset($_POST['delete'])) {
            $id = $_POST['id'];
            $sql = "DELETE FROM books WHERE id = $id";

            if ($conn->query($sql) === TRUE) {
                echo "<p style='color: green; margin-top: 20px;'>Book deleted successfully!</p>";
            } else {
                echo "<p style='color: red; margin-top: 20px;'>Error deleting book: " . $conn->error . "</p>";
            }
        }
        ?>
    </div>

</body>
</html>
