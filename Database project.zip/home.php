<?php
if ($_POST['username'] === 'admin' && $_POST['password'] === '1234') {
    echo "
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('assets/file.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }
        .container {
            background-color: rgba(0, 0, 0, 0.5); /* Transparent background */
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5);
        }
        h1 {
            margin-bottom: 20px;
        }
        a {
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 0 10px;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: inline-block;
        }
        a:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
    </style>
    <div class='container'>
        <h1>Welcome to Library Management System</h1>
        <a href='add.php'>Add Book</a>
        <a href='show.php'>Show Books</a>
        <a href='delete.php'>Delete Book</a>
        <a href='update.php'>Update Book</a>
        <a href='search.php'>Search Book</a>
    </div>";
} else {
    echo "
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('assets/file.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }
        .error {
            background-color: rgba(255, 0, 0, 0.5); /* Transparent red background */
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5);
            font-size: 18px;
        }
    </style>
    <div class='error'>
        Invalid Credentials!
    </div>";
}
?>
