<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Books</title>
   <style>
    /* General styling for the body */
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #4facfe, #00f2fe);
    color: #333;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
}

/* Container styling */
.container {
    background: rgba(255, 255, 255, 0.9);
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5);
    width: 500px;
    text-align: center;
}

/* Title styling */
.title {
    color: #5bc0de;
    margin-bottom: 20px;
}

/* Form styling */
.search-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-bottom: 20px;
}

.input-field {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
}

.btn {
    background-color: #5bc0de;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.btn:hover {
    background-color: #3498db;
}

/* Table styling */
.styled-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    font-size: 16px;
}

.styled-table thead tr {
    background-color: #3498db;
    color: #ffffff;
    text-align: left;
}

.styled-table th,
.styled-table td {
    padding: 10px;
    border: 1px solid #ddd;
}

.styled-table tbody tr:nth-child(even) {
    background-color: #f3f3f3;
}

.styled-table tbody tr:hover {
    background-color: #f1f1f1;
}

/* No books message styling */
.no-books {
    color: red;
    margin-top: 20px;
}

   </style>
</head>
<body>
    <div class="container">
        <h2 class="title">Search Books</h2>
        <form method="post" class="search-form">
            <input type="text" name="search" placeholder="Enter Title or Author" class="input-field">
            <button type="submit" name="searchBtn" class="btn">Search</button>
        </form>

        <?php
        if (isset($_POST['searchBtn'])) {
            $search = $_POST['search'];
            $sql = "SELECT * FROM books WHERE title LIKE '%$search%' OR author LIKE '%$search%'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table class='styled-table'>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Genre</th>
                                <th>Year</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['title']}</td>
                            <td>{$row['author']}</td>
                            <td>{$row['genre']}</td>
                            <td>{$row['year']}</td>
                            <td>{$row['quantity']}</td>
                          </tr>";
                }
                echo "  </tbody>
                      </table>";
            } else {
                echo "<p class='no-books'>No books found!</p>";
            }
        }
        ?>
    </div>
</body>
</html>
