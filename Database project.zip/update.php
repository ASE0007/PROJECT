<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Book</title>
</head>
<body style="font-family: Arial, sans-serif; background: linear-gradient(to right, #4facfe, #00f2fe); color: #333; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0;">

    <div style="background: rgba(255, 255, 255, 0.9); padding: 20px 30px; border-radius: 10px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.5); width: 400px; text-align: center;">
        <h2 style="color: #5bc0de; margin-bottom: 20px;">Update Book</h2>
        <form method="post" style="display: flex; flex-direction: column; gap: 15px;">
            <input type="number" name="id" placeholder="Enter Book ID to Update" required style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
            <input type="text" name="title" placeholder="New Title" style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
            <input type="text" name="author" placeholder="New Author" style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
            <input type="text" name="genre" placeholder="New Genre" style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
            <input type="number" name="year" placeholder="New Year" style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
            <input type="number" name="quantity" placeholder="New Quantity" min="0" style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
            <button type="submit" name="update" style="background-color: #5bc0de; color: white; padding: 10px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; transition: background-color 0.3s;">
                Update Book
            </button>
        </form>
        <?php
        if (isset($_POST['update'])) {
            $id = $_POST['id'];
            $title = $_POST['title'];
            $author = $_POST['author'];
            $genre = $_POST['genre'];
            $year = $_POST['year'];
            $quantity = isset($_POST['quantity']) && $_POST['quantity'] !== '' ? $_POST['quantity'] : 'NULL';

            $sql = "UPDATE books SET 
                    title = IF('$title' = '', title, '$title'),
                    author = IF('$author' = '', author, '$author'),
                    genre = IF('$genre' = '', genre, '$genre'),
                    year = IF('$year' = '', year, '$year'),
                    quantity = IF($quantity IS NULL, quantity, $quantity)
                    WHERE id = $id";

            if ($conn->query($sql) === TRUE) {
                echo "<p style='color: green; margin-top: 20px;'>Book updated successfully!</p>";
            } else {
                echo "<p style='color: red; margin-top: 20px;'>Error updating book: " . $conn->error . "</p>";
            }
        }
        ?>
    </div>

</body>
</html>
