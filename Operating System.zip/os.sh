#!/bin/bash

# File to store book records
LIBRARY_FILE="library.txt"

# Ensure the library file exists
touch "$LIBRARY_FILE"

# Function to add a book
add_book() {
    echo "Enter book title:"
    read -r book_title
    echo "Enter author name:"
    read -r author_name
    echo "Enter publication year:"
    read -r publication_year
    echo "Enter language:"
    read -r language
    echo "Enter price:"
    read -r price

    echo "$book_title,$author_name,$publication_year,$language,$price" >> "$LIBRARY_FILE"
    echo "Book '$book_title' by $author_name added successfully."
    echo
}

# Function to delete a book
delete_book() {
    if [[ ! -s $LIBRARY_FILE ]]; then
        echo "No books available to delete."
        return
    fi

    show_books
    echo "Enter the book number to delete:"
    read -r book_number

    if [[ $book_number =~ ^[0-9]+$ ]] && ((book_number > 0 && book_number <= $(wc -l < "$LIBRARY_FILE"))); then
        sed -i "${book_number}d" "$LIBRARY_FILE"
        echo "Book number $book_number deleted successfully."
    else
        echo "Invalid book number."
    fi
    echo
}

# Function to edit a book
edit_book() {
    if [[ ! -s $LIBRARY_FILE ]]; then
        echo "No books available to edit."
        return
    fi

    show_books
    echo "Enter the book number to edit:"
    read -r book_number

    if [[ $book_number =~ ^[0-9]+$ ]] && ((book_number > 0 && book_number <= $(wc -l < "$LIBRARY_FILE"))); then
        old_entry=$(sed -n "${book_number}p" "$LIBRARY_FILE")
        IFS=',' read -r old_title old_author old_year old_language old_price <<< "$old_entry"

        echo "Editing book: $old_title by $old_author"
        echo "Enter new book title (leave empty to keep '$old_title'):"
        read -r new_title
        echo "Enter new author name (leave empty to keep '$old_author'):"
        read -r new_author
        echo "Enter new publication year (leave empty to keep '$old_year'):"
        read -r new_year
        echo "Enter new language (leave empty to keep '$old_language'):"
        read -r new_language
        echo "Enter new price (leave empty to keep '$old_price'):"
        read -r new_price

        new_title=${new_title:-$old_title}
        new_author=${new_author:-$old_author}
        new_year=${new_year:-$old_year}
        new_language=${new_language:-$old_language}
        new_price=${new_price:-$old_price}

        sed -i "${book_number}s/.*/$new_title,$new_author,$new_year,$new_language,$new_price/" "$LIBRARY_FILE"
        echo "Book updated successfully."
    else
        echo "Invalid book number."
    fi
    echo
}

# Function to search for a book
search_book() {
    if [[ ! -s $LIBRARY_FILE ]]; then
        echo "No books available to search."
        return
    fi

    echo "Enter search term (book title, author, year, language, or price):"
    read -r search_term
    search_term=$(echo "$search_term" | tr '[:upper:]' '[:lower:]')

    echo "Search Results:"
    grep -i "$search_term" "$LIBRARY_FILE" | nl -s ". "
    echo
}

# Function to show all books
show_books() {
    if [[ ! -s $LIBRARY_FILE ]]; then
        echo "No books available."
        return
    fi

    echo "Library Books:"
    nl -s ". " "$LIBRARY_FILE" | awk -F, '{print $1 " by " $2 " (" $3 ", " $4 ") - Price: $" $5}'
    echo
}

# Function to display the menu
menu() {
    echo "Library Management System"
    echo "1. Add Book"
    echo "2. Delete Book"
    echo "3. Edit Book"
    echo "4. Search Book"
    echo "5. Show Books"
    echo "6. Exit"
    echo
}

# Main function to run the system
library_management_system() {
    while true; do
        menu
        echo "Select an option (1-6):"
        read -r choice

        case $choice in
        1) add_book ;;
        2) delete_book ;;
        3) edit_book ;;
        4) search_book ;;
        5) show_books ;;
        6)
            echo "Exiting the Library Management System. Goodbye!"
            break
            ;;
        *)
            echo "Invalid choice. Please select a valid option."
            ;;
        esac
    done
}

# Run the program
library_management_system
